
class ehandle
{
  
  public static void main(String args[])
  { 

     int a=10,b=5,c=5;
    int x=0,y=0;
     try
    {

      x=a/(b-c);
     
     }
catch(Exception e)
{
   System.out.println(e);
}
      y=a/(b+c);
         System.out.println("x="+x);
     System.out.println("y="+y);
     
    }
}








    