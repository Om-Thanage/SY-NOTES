
class ehandle3
{
  
  public static void main(String args[])
  { 

     int a=10,b=5,c=5;
    int x,y;
x=a/(b-c);
      y=a/(b+c);
      System.out.println("x="+x);
     System.out.println("y="+y);
     
    }
}








    