package package1;
public class ClassA
{
  public void displayA()
  {
     System.out.println("Class A in a package");
    }
}