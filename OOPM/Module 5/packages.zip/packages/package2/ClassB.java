package package2;
public class ClassB
{
  protected int m=10;  
  public void displayB()
  {
     System.out.println("Class B in a package 2");
     System.out.println("m="+m);
    }
}